package ch.stfw.hfit18.onlineShoppingList.model;

public enum Status {
	In_Bearbeitung, 
	Erledigt;
}
