package ch.stfw.hfit18.onlineShoppingList.model;

public enum Categorie {
	Frucht, 
	Gemuese,
	Fleisch,
	Milchprodukt,
	Teigwaren,
	Spielwaren,
	Buecher,
	Kleidung,
	Sonstiges;
}
