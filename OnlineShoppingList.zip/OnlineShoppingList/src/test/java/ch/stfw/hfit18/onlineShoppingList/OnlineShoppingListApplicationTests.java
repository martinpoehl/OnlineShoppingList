package ch.stfw.hfit18.onlineShoppingList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineEinkaufslisteApplicationTests {

	@Test
	void contextLoads() {
	}

}
